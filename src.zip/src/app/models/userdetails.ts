export class user_details
{
  public user_email?:string
  public password?:string
  public role?:string
}
