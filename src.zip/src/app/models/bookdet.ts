export class bookdet
{
  public  transid?:number;
  public bkids?:number;
  public studentname?:string;
  public fine?:number;
  public returndate?:Date;
  public issuedate?:Date;
}
