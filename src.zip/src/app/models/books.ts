export class books
{
public bkid?:number;
public bknm?:string;
public author?:string;
public price?:string;
public image?:Blob;
public description?:string;
public status?:string;
}
